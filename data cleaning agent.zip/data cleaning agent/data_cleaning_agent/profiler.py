"""
Data profiling module for analyzing and detecting data quality issues
"""
import pandas as pd
import numpy as np
from ydata_profiling import ProfileReport
from typing import Dict, Any, Optional
import json

class DataProfiler:
    def __init__(self, minimal: bool = True):
        self.minimal = minimal

    def profile_data(self, df: pd.DataFrame, report_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Profile the dataset and generate a report
        
        Args:
            df: Input DataFrame
            report_path: Optional path to save the HTML report
            
        Returns:
            Dictionary containing profiling results
        """
        profile = ProfileReport(df, minimal=self.minimal)
        
        if report_path:
            profile.to_file(report_path)
            
        # Extract key metrics
        metrics = {
            "missing_values": df.isnull().sum().to_dict(),
            "duplicates": df.duplicated().sum(),
            "data_types": df.dtypes.astype(str).to_dict(),
            "basic_stats": df.describe().to_dict()
        }
        
        return metrics

    def detect_issues(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Detect common data issues
        
        Args:
            df: Input DataFrame
            
        Returns:
            Dictionary of detected issues
        """
        issues = {
            "missing_values": df.isnull().sum()[df.isnull().sum() > 0].to_dict(),
            "duplicates": df.duplicated().sum(),
            "outliers": self._detect_outliers(df),
            "inconsistent_formats": self._check_formats(df)
        }
        
        return issues

    def _detect_outliers(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Detect outliers using IQR method"""
        outliers = {}
        for col in df.select_dtypes(include=['float64', 'int64']).columns:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            outliers[col] = df[(df[col] < (Q1 - 1.5 * IQR)) | (df[col] > (Q3 + 1.5 * IQR))].shape[0]
        return outliers

    def _check_formats(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Check for inconsistent formats in string columns"""
        format_issues = {}
        for col in df.select_dtypes(include=['object']).columns:
            # Check for mixed case
            if df[col].str.islower().any() and df[col].str.isupper().any():
                format_issues[col] = "mixed_case"
            # Check for inconsistent date formats if column looks like dates
            if df[col].str.match(r'\d{4}-\d{2}-\d{2}').any() and \
               df[col].str.match(r'\d{2}/\d{2}/\d{4}').any():
                format_issues[col] = "inconsistent_date_format"
        return format_issues 