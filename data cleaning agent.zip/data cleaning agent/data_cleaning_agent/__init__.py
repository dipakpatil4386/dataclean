"""
Data Cleaning Agent - An AI-powered tool for automated data cleaning
"""

__version__ = "0.1.0" 