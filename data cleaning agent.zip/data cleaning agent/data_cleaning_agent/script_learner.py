"""
Script learning module to extract cleaning patterns from previous scripts
"""
import glob
import ast
from typing import List, Dict, Any
import pandas as pd

class ScriptLearner:
    def __init__(self, scripts_dir: str):
        self.scripts_dir = scripts_dir
        self.cleaning_patterns = {}

    def learn_from_scripts(self) -> Dict[str, Any]:
        """
        Learn cleaning patterns from previous scripts
        
        Returns:
            Dictionary of learned cleaning patterns
        """
        for script_path in glob.glob(f"{self.scripts_dir}/*.py"):
            self._analyze_script(script_path)
        return self.cleaning_patterns

    def _analyze_script(self, script_path: str):
        """Analyze a single script for cleaning patterns"""
        with open(script_path, 'r') as f:
            try:
                tree = ast.parse(f.read())
                for node in ast.walk(tree):
                    if isinstance(node, ast.Call):
                        self._extract_cleaning_operation(node)
            except SyntaxError:
                print(f"Could not parse {script_path}")

    def _extract_cleaning_operation(self, node: ast.Call):
        """Extract cleaning operations from AST nodes"""
        if isinstance(node.func, ast.Attribute):
            method_name = node.func.attr
            if method_name in ['dropna', 'fillna', 'replace', 'astype']:
                if method_name not in self.cleaning_patterns:
                    self.cleaning_patterns[method_name] = []
                
                # Extract arguments
                args = []
                for arg in node.args:
                    if isinstance(arg, ast.Constant):
                        args.append(arg.value)
                
                # Extract keyword arguments
                kwargs = {}
                for kw in node.keywords:
                    kwargs[kw.arg] = kw.value.value if isinstance(kw.value, ast.Constant) else None
                
                self.cleaning_patterns[method_name].append({
                    'args': args,
                    'kwargs': kwargs
                })

    def suggest_cleaning_steps(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Suggest cleaning steps based on learned patterns
        
        Args:
            df: Input DataFrame
            
        Returns:
            List of suggested cleaning steps
        """
        suggestions = []
        
        # Check for missing values
        if df.isnull().any().any():
            if 'fillna' in self.cleaning_patterns:
                suggestions.append({
                    'operation': 'fillna',
                    'description': 'Fill missing values based on learned patterns',
                    'patterns': self.cleaning_patterns['fillna']
                })
        
        # Check for duplicates
        if df.duplicated().any():
            suggestions.append({
                'operation': 'drop_duplicates',
                'description': 'Remove duplicate rows'
            })
        
        # Check for outliers
        for col in df.select_dtypes(include=['float64', 'int64']).columns:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            outliers = df[(df[col] < (Q1 - 1.5 * IQR)) | (df[col] > (Q3 + 1.5 * IQR))]
            if not outliers.empty:
                suggestions.append({
                    'operation': 'handle_outliers',
                    'column': col,
                    'description': f'Handle outliers in {col}',
                    'outlier_count': len(outliers)
                })
        
        return suggestions 