"""
Main cleaning agent module that orchestrates the data cleaning process
"""
from typing import Dict, Any, List, Optional
import pandas as pd
from .profiler import DataProfiler
from .script_learner import ScriptLearner
from .doc_learner import DocLearner
from pycaret.classification import setup, compare_models

class DataCleaningAgent:
    def __init__(
        self,
        scripts_dir: str,
        docs_dir: str,
        openai_api_key: Optional[str] = None
    ):
        self.profiler = DataProfiler()
        self.script_learner = ScriptLearner(scripts_dir)
        self.doc_learner = DocLearner(openai_api_key)
        self.docs_dir = docs_dir
        self.cleaning_history = []

    def clean_data(
        self,
        df: pd.DataFrame,
        target_column: Optional[str] = None,
        auto_clean: bool = True
    ) -> Dict[str, Any]:
        """
        Main method to clean the data
        
        Args:
            df: Input DataFrame
            target_column: Optional target column for AutoML
            auto_clean: Whether to automatically apply cleaning steps
            
        Returns:
            Dictionary containing cleaning results and suggestions
        """
        # 1. Profile the data
        profile_results = self.profiler.profile_data(df)
        issues = self.profiler.detect_issues(df)
        
        # 2. Learn from previous scripts
        script_patterns = self.script_learner.learn_from_scripts()
        script_suggestions = self.script_learner.suggest_cleaning_steps(df)
        
        # 3. Learn from documentation
        doc_paths = [f"{self.docs_dir}/{f}" for f in os.listdir(self.docs_dir) if f.endswith('.md')]
        doc_learnings = self.doc_learner.learn_from_docs(doc_paths)
        
        # 4. Combine suggestions
        all_suggestions = self._combine_suggestions(
            script_suggestions,
            doc_learnings["cleaning_steps"]
        )
        
        # 5. Apply AutoML if target column is provided
        automl_results = None
        if target_column and auto_clean:
            automl_results = self._apply_automl(df, target_column)
        
        # 6. Apply cleaning steps if auto_clean is True
        cleaned_df = df.copy()
        if auto_clean:
            cleaned_df = self._apply_cleaning_steps(cleaned_df, all_suggestions)
        
        # 7. Record cleaning history
        self.cleaning_history.append({
            "original_shape": df.shape,
            "cleaned_shape": cleaned_df.shape,
            "issues_found": issues,
            "suggestions": all_suggestions,
            "automl_results": automl_results
        })
        
        return {
            "profile_results": profile_results,
            "issues": issues,
            "suggestions": all_suggestions,
            "automl_results": automl_results,
            "cleaned_data": cleaned_df,
            "cleaning_history": self.cleaning_history
        }

    def _combine_suggestions(
        self,
        script_suggestions: List[Dict[str, Any]],
        doc_suggestions: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Combine suggestions from scripts and documentation"""
        all_suggestions = script_suggestions.copy()
        
        # Add unique suggestions from documentation
        for doc_suggestion in doc_suggestions:
            if not any(
                s["operation"] == doc_suggestion["operation"]
                for s in all_suggestions
            ):
                all_suggestions.append(doc_suggestion)
        
        return all_suggestions

    def _apply_automl(self, df: pd.DataFrame, target_column: str) -> Dict[str, Any]:
        """Apply AutoML for advanced cleaning"""
        try:
            # Setup PyCaret
            setup(
                data=df,
                target=target_column,
                silent=True,
                html=False
            )
            
            # Compare models
            best_model = compare_models()
            
            return {
                "best_model": str(best_model),
                "model_performance": best_model.get_params()
            }
        except Exception as e:
            return {
                "error": str(e),
                "status": "failed"
            }

    def _apply_cleaning_steps(
        self,
        df: pd.DataFrame,
        suggestions: List[Dict[str, Any]]
    ) -> pd.DataFrame:
        """Apply cleaning steps to the DataFrame"""
        for suggestion in suggestions:
            operation = suggestion["operation"]
            
            try:
                if operation == "fillna":
                    # Apply fillna based on learned patterns
                    for pattern in suggestion.get("patterns", []):
                        df = df.fillna(**pattern.get("kwargs", {}))
                
                elif operation == "drop_duplicates":
                    df = df.drop_duplicates()
                
                elif operation == "handle_outliers":
                    col = suggestion["column"]
                    Q1 = df[col].quantile(0.25)
                    Q3 = df[col].quantile(0.75)
                    IQR = Q3 - Q1
                    df = df[
                        (df[col] >= (Q1 - 1.5 * IQR)) &
                        (df[col] <= (Q3 + 1.5 * IQR))
                    ]
                
                # Add more operations as needed
                
            except Exception as e:
                print(f"Error applying {operation}: {str(e)}")
                continue
        
        return df

    def get_cleaning_report(self) -> Dict[str, Any]:
        """Generate a cleaning report from history"""
        if not self.cleaning_history:
            return {"status": "No cleaning history available"}
        
        latest_cleaning = self.cleaning_history[-1]
        return {
            "total_cleanings": len(self.cleaning_history),
            "latest_cleaning": {
                "original_shape": latest_cleaning["original_shape"],
                "cleaned_shape": latest_cleaning["cleaned_shape"],
                "issues_found": latest_cleaning["issues_found"],
                "suggestions_applied": latest_cleaning["suggestions"],
                "automl_results": latest_cleaning["automl_results"]
            }
        } 