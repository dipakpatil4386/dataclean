"""
Documentation learning module using LangChain and OpenAI
"""
from typing import List, Dict, Any
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
import os
from dotenv import load_dotenv

load_dotenv()

class DocLearner:
    def __init__(self, openai_api_key: str = None):
        self.openai_api_key = openai_api_key or os.getenv("OPENAI_API_KEY")
        if not self.openai_api_key:
            raise ValueError("OpenAI API key is required")
        
        self.llm = OpenAI(temperature=0, openai_api_key=self.openai_api_key)
        self._setup_chains()

    def _setup_chains(self):
        """Setup LangChain chains for different learning tasks"""
        # Chain for extracting cleaning steps
        cleaning_template = """
        Extract data cleaning steps from the following documentation:
        
        {doc_text}
        
        Format the output as a list of cleaning steps, each with:
        - operation: The cleaning operation to perform
        - description: A brief description of what the operation does
        - parameters: Any parameters needed for the operation
        
        Output:
        """
        self.cleaning_chain = LLMChain(
            llm=self.llm,
            prompt=PromptTemplate(
                input_variables=["doc_text"],
                template=cleaning_template
            )
        )

        # Chain for understanding data quality rules
        quality_template = """
        Extract data quality rules and validation criteria from the following documentation:
        
        {doc_text}
        
        Format the output as a list of rules, each with:
        - rule: The data quality rule
        - validation: How to validate this rule
        - severity: The severity of violating this rule (high/medium/low)
        
        Output:
        """
        self.quality_chain = LLMChain(
            llm=self.llm,
            prompt=PromptTemplate(
                input_variables=["doc_text"],
                template=quality_template
            )
        )

    def learn_from_docs(self, doc_paths: List[str]) -> Dict[str, Any]:
        """
        Learn cleaning patterns from documentation files
        
        Args:
            doc_paths: List of paths to documentation files
            
        Returns:
            Dictionary containing learned patterns and rules
        """
        cleaning_steps = []
        quality_rules = []
        
        for doc_path in doc_paths:
            with open(doc_path, 'r', encoding='utf-8') as f:
                doc_text = f.read()
                
                # Extract cleaning steps
                cleaning_result = self.cleaning_chain.run(doc_text=doc_text)
                cleaning_steps.extend(self._parse_cleaning_steps(cleaning_result))
                
                # Extract quality rules
                quality_result = self.quality_chain.run(doc_text=doc_text)
                quality_rules.extend(self._parse_quality_rules(quality_result))
        
        return {
            "cleaning_steps": cleaning_steps,
            "quality_rules": quality_rules
        }

    def _parse_cleaning_steps(self, result: str) -> List[Dict[str, Any]]:
        """Parse the cleaning steps from LLM output"""
        # This is a simplified parser - in practice, you'd want more robust parsing
        steps = []
        current_step = {}
        
        for line in result.split('\n'):
            line = line.strip()
            if line.startswith('- operation:'):
                if current_step:
                    steps.append(current_step)
                current_step = {'operation': line.split(':', 1)[1].strip()}
            elif line.startswith('- description:'):
                current_step['description'] = line.split(':', 1)[1].strip()
            elif line.startswith('- parameters:'):
                current_step['parameters'] = line.split(':', 1)[1].strip()
        
        if current_step:
            steps.append(current_step)
        
        return steps

    def _parse_quality_rules(self, result: str) -> List[Dict[str, Any]]:
        """Parse the quality rules from LLM output"""
        # This is a simplified parser - in practice, you'd want more robust parsing
        rules = []
        current_rule = {}
        
        for line in result.split('\n'):
            line = line.strip()
            if line.startswith('- rule:'):
                if current_rule:
                    rules.append(current_rule)
                current_rule = {'rule': line.split(':', 1)[1].strip()}
            elif line.startswith('- validation:'):
                current_rule['validation'] = line.split(':', 1)[1].strip()
            elif line.startswith('- severity:'):
                current_rule['severity'] = line.split(':', 1)[1].strip()
        
        if current_rule:
            rules.append(current_rule)
        
        return rules 