"""
Main script demonstrating the usage of the Data Cleaning Agent
"""
import os
import pandas as pd
from dotenv import load_dotenv
from data_cleaning_agent.cleaning_agent import DataCleaningAgent

# Load environment variables
load_dotenv()

def main():
    # Example usage
    # 1. Initialize the agent
    agent = DataCleaningAgent(
        scripts_dir="scripts",
        docs_dir="docs",
        openai_api_key=os.getenv("OPENAI_API_KEY")
    )
    
    # 2. Load your data
    # Replace this with your actual data loading code
    df = pd.read_csv("data/raw_data.csv")
    
    # 3. Clean the data
    results = agent.clean_data(
        df=df,
        target_column="target",  # Replace with your target column if applicable
        auto_clean=True
    )
    
    # 4. Print results
    print("\nData Cleaning Results:")
    print("---------------------")
    print(f"Original shape: {results['profile_results']['original_shape']}")
    print(f"Cleaned shape: {results['cleaned_data'].shape}")
    
    print("\nIssues Found:")
    for issue_type, details in results['issues'].items():
        print(f"\n{issue_type}:")
        print(details)
    
    print("\nCleaning Suggestions:")
    for suggestion in results['suggestions']:
        print(f"\n- {suggestion['operation']}: {suggestion.get('description', '')}")
    
    if results['automl_results']:
        print("\nAutoML Results:")
        print(results['automl_results'])
    
    # 5. Save cleaned data
    results['cleaned_data'].to_csv("data/cleaned_data.csv", index=False)
    print("\nCleaned data saved to 'data/cleaned_data.csv'")

if __name__ == "__main__":
    main() 