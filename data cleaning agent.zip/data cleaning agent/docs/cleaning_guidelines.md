# Data Cleaning Guidelines

## Missing Values
- Age: Fill missing values with the median age
- Salary: Fill missing values with the department's median salary
- Other fields: Drop rows with missing values if critical, otherwise fill with appropriate defaults

## Outliers
- Salary: Use IQR method to detect and handle outliers
- Age: Values outside 18-65 range should be reviewed
- Other numeric fields: Use domain knowledge to determine appropriate ranges

## Data Types
- Join date: Convert to datetime format (YYYY-MM-DD)
- Salary: Should be numeric
- Department: Should be categorical
- Age: Should be numeric

## Duplicates
- Remove exact duplicates
- For near-duplicates, keep the most recent record

## Formatting
- Names: Title case
- Department: Uppercase
- Dates: YYYY-MM-DD format

## Validation Rules
- Age must be between 18 and 65
- Salary must be positive
- Join date must not be in the future
- Department must be one of: IT, HR, Finance 