"""
Sample cleaning script demonstrating common data cleaning operations
"""
import pandas as pd

def clean_employee_data(df):
    # Fill missing ages with median
    df['age'] = df['age'].fillna(df['age'].median())
    
    # Fill missing salaries with department median
    df['salary'] = df.groupby('department')['salary'].transform(
        lambda x: x.fillna(x.median())
    )
    
    # Convert join_date to datetime
    df['join_date'] = pd.to_datetime(df['join_date'])
    
    # Remove duplicates
    df = df.drop_duplicates()
    
    # Handle outliers in salary (using IQR method)
    Q1 = df['salary'].quantile(0.25)
    Q3 = df['salary'].quantile(0.75)
    IQR = Q3 - Q1
    df = df[
        (df['salary'] >= (Q1 - 1.5 * IQR)) &
        (df['salary'] <= (Q3 + 1.5 * IQR))
    ]
    
    return df 