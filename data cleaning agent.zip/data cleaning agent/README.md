# AI-Powered Data Cleaning Agent

An intelligent data cleaning agent that automatically detects and cleans data issues by learning from prior cleaning scripts and documentation. Built with LangChain, Python, Pandas Profiling, OpenAI/GPT-4, and AutoML.

## Features

- **Automated Data Profiling**: Detect outliers, nulls, and formatting issues
- **Learning from History**: Learn cleaning patterns from previous scripts
- **Documentation Analysis**: Extract cleaning rules from documentation using LLMs
- **AutoML Integration**: Advanced cleaning suggestions using PyCaret
- **Customizable Cleaning**: Apply cleaning steps automatically or get suggestions

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd data-cleaning-agent
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up environment variables:
Create a `.env` file in the root directory with:
```
OPENAI_API_KEY=your_openai_api_key
```

## Project Structure

```
data-cleaning-agent/
│
├── data/                  # Raw and cleaned datasets
├── scripts/               # Previous cleaning scripts
├── docs/                  # Cleaning documentation
├── data_cleaning_agent/   # Main package
│   ├── __init__.py
│   ├── profiler.py
│   ├── script_learner.py
│   ├── doc_learner.py
│   └── cleaning_agent.py
├── requirements.txt
├── main.py
└── README.md
```

## Usage

1. Place your raw data in the `data/` directory
2. Add any previous cleaning scripts to the `scripts/` directory
3. Add cleaning documentation to the `docs/` directory
4. Run the cleaning agent:

```python
from data_cleaning_agent.cleaning_agent import DataCleaningAgent
import pandas as pd

# Initialize the agent
agent = DataCleaningAgent(
    scripts_dir="scripts",
    docs_dir="docs",
    openai_api_key="your_openai_api_key"
)

# Load your data
df = pd.read_csv("data/your_data.csv")

# Clean the data
results = agent.clean_data(
    df=df,
    target_column="target",  # Optional: for AutoML
    auto_clean=True
)

# Access results
cleaned_data = results['cleaned_data']
suggestions = results['suggestions']
```

## Example

```python
# main.py
import pandas as pd
from data_cleaning_agent.cleaning_agent import DataCleaningAgent

# Initialize agent
agent = DataCleaningAgent(
    scripts_dir="scripts",
    docs_dir="docs",
    openai_api_key="your_openai_api_key"
)

# Load and clean data
df = pd.read_csv("data/raw_data.csv")
results = agent.clean_data(df, auto_clean=True)

# Save cleaned data
results['cleaned_data'].to_csv("data/cleaned_data.csv", index=False)
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

MIT License

## Acknowledgments

- LangChain for LLM integration
- Pandas Profiling for data analysis
- PyCaret for AutoML capabilities
- OpenAI for GPT-4 integration 